# wa-bot-pairing
 Get Your Creds.Json File for your bot
