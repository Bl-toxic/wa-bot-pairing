# WhatsApp Pairing Session
 Get Your Creds.Json File for your bot

 ### Heroku 
 [Click Here](https://pairing-web-session-for-whatsa-74cae2de7758.herokuapp.com/)
